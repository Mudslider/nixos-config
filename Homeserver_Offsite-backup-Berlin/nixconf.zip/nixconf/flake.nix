{
  description = "A very basic flake";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs?ref=nixos-unstable";

    # Secrets Manager
    agenix= {
      url = "github:yaxitech/ragenix";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, agenix, ... }@inputs:
  let
    lib = nixpkgs.lib;
    system = "x86_64-linux";
    pkgs = nixpkgs.legacyPackages.${system};
  in {

    nixosConfigurations.nixos = lib.nixosSystem {
      inherit system;
      specialArgs = { inherit self inputs; };
      modules = [
        # host config
        ./configuration.nix

        # Secrets Manager
        agenix.nixosModules.default
      ];
    };
  };
}
