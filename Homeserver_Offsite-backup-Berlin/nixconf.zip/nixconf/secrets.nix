{
  age = {
    secrets = {
      netbird-key = {
        file = ./secrets/netbird-key.age;
      };
    };
  };
}
