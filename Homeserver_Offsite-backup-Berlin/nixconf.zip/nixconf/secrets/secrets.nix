let
  admin = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAICf6KF1795RRBLNYMSUIJM0TrWImxe7Q8VPsuUUHyVFU";
in
{
  "netbird-key.age".publicKeys = [ admin ];
}
